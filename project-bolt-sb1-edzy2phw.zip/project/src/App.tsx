import React from 'react';
import Header from './components/Header';
import FloatingButtons from './components/FloatingButtons';
import Hero from './components/sections/Hero';
import About from './components/sections/About';
import Services from './components/sections/Services';
import Achievements from './components/sections/Achievements';
import Portfolio from './components/sections/Portfolio';
import Testimonials from './components/sections/Testimonials';
import Faq from './components/sections/Faq';
import Footer from './components/Footer';

function App() {
  return (
    <div className="font-body text-darkGrey bg-white">
      <Header />
      <main>
        <Hero />
        <About />
        <Services />
        <Achievements />
        <Portfolio />
        <Testimonials />
        <Faq />
      </main>
      <Footer />
      <FloatingButtons />
    </div>
  );
}

export default App;