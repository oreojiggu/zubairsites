import React from 'react';
import { Phone, MessageCircle } from 'lucide-react';

const FloatingButtons: React.FC = () => {
  return (
    <div className="fixed left-4 bottom-4 z-40 flex flex-col space-y-2">
      <a
        href="https://wa.me/919596320118"
        className="btn-floating bg-green text-white p-3 rounded-full shadow-lg hover:bg-darkGreen transition-all duration-300 flex items-center justify-center"
        aria-label="WhatsApp Us"
      >
        <MessageCircle className="h-6 w-6" />
      </a>
      
      <a
        href="tel:+91-9596320118"
        className="btn-floating bg-darkGreen text-white p-3 rounded-full shadow-lg hover:bg-green transition-all duration-300 flex items-center justify-center"
        aria-label="Call Us"
      >
        <Phone className="h-6 w-6" />
      </a>
    </div>
  );
};

export default FloatingButtons;