import React, { useEffect, useRef } from 'react';
import { ExternalLink } from 'lucide-react';

const Portfolio: React.FC = () => {
  const portfolioRef = useRef<HTMLDivElement>(null);
  
  useEffect(() => {
    const handleIntersection = (entries: IntersectionObserverEntry[]) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          entry.target.classList.add('visible');
        }
      });
    };
    
    const observer = new IntersectionObserver(handleIntersection, { threshold: 0.1 });
    
    if (portfolioRef.current) {
      observer.observe(portfolioRef.current);
    }
    
    return () => {
      if (portfolioRef.current) {
        observer.unobserve(portfolioRef.current);
      }
    };
  }, []);
  
  return (
    <section id="portfolio" ref={portfolioRef} className="section bg-white">
      <div className="container-custom">
        <h2 className="section-heading text-center mx-auto slide-up">Our Portfolio</h2>
        <p className="text-center max-w-2xl mx-auto mb-12 slide-up">
          Explore our impressive collection of websites and digital solutions we've created for clients across various industries.
        </p>
        
        <div className="relative bg-gradient-to-r from-darkGreen to-green p-12 rounded-lg text-white text-center slide-up">
          <div className="absolute inset-0 bg-darkGreen opacity-80 rounded-lg"></div>
          
          {/* Animated dots pattern */}
          <div className="absolute inset-0 overflow-hidden">
            {Array.from({ length: 20 }).map((_, i) => (
              <div 
                key={i}
                className="absolute rounded-full bg-white/10"
                style={{
                  width: `${Math.random() * 20 + 5}px`,
                  height: `${Math.random() * 20 + 5}px`,
                  top: `${Math.random() * 100}%`,
                  left: `${Math.random() * 100}%`,
                  animation: `pulse ${Math.random() * 3 + 2}s infinite`
                }}
              ></div>
            ))}
          </div>
          
          <div className="relative z-10">
            <h3 className="text-3xl font-bold mb-6">Browse Our Extensive Portfolio</h3>
            <p className="text-lg mb-8 max-w-2xl mx-auto">
              View our complete portfolio to see the range of websites and digital solutions we've delivered for businesses across different industries.
            </p>
            <a 
              href="https://www.zubairlone.in" 
              target="_blank" 
              rel="noopener noreferrer"
              className="btn btn-primary inline-flex items-center"
            >
              Click Here to view our work
              <ExternalLink className="ml-2 h-5 w-5" />
            </a>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Portfolio;