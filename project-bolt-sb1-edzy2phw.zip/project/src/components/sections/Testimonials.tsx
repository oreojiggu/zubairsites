import React, { useEffect, useRef } from 'react';
import { ExternalLink, Star } from 'lucide-react';

const Testimonials: React.FC = () => {
  const testimonialsRef = useRef<HTMLDivElement>(null);
  
  useEffect(() => {
    const handleIntersection = (entries: IntersectionObserverEntry[]) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          entry.target.classList.add('visible');
        }
      });
    };
    
    const observer = new IntersectionObserver(handleIntersection, { threshold: 0.1 });
    
    if (testimonialsRef.current) {
      observer.observe(testimonialsRef.current);
    }
    
    return () => {
      if (testimonialsRef.current) {
        observer.unobserve(testimonialsRef.current);
      }
    };
  }, []);
  
  return (
    <section id="testimonials" ref={testimonialsRef} className="section bg-gray-50">
      <div className="container-custom">
        <h2 className="section-heading text-center mx-auto slide-up">Testimonials</h2>
        <p className="text-center max-w-2xl mx-auto mb-12 slide-up">
          Don't just take our word for it. See what our clients have to say about our services.
        </p>
        
        <div className="relative bg-white p-12 rounded-lg text-center shadow-lg slide-up">
          <div className="flex justify-center mb-6">
            {[...Array(5)].map((_, i) => (
              <Star key={i} className="h-8 w-8 text-yellow-400 fill-current" />
            ))}
          </div>
          
          <p className="text-lg italic mb-8 max-w-3xl mx-auto">
            "We've received countless positive reviews from satisfied clients who appreciate our professionalism, attention to detail, and commitment to delivering exceptional results. Our clients love how we transform their ideas into beautiful, functional websites that help grow their businesses."
          </p>
          
          <a 
            href="https://www.zubairlone.in" 
            target="_blank" 
            rel="noopener noreferrer"
            className="btn btn-primary inline-flex items-center"
          >
            Click Here to check out our reviews
            <ExternalLink className="ml-2 h-5 w-5" />
          </a>
        </div>
      </div>
    </section>
  );
};

export default Testimonials;