import React, { useEffect, useRef } from 'react';

const About: React.FC = () => {
  const aboutRef = useRef<HTMLDivElement>(null);
  
  useEffect(() => {
    const handleIntersection = (entries: IntersectionObserverEntry[]) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          const elements = entry.target.querySelectorAll('.animate-element');
          elements.forEach((el, index) => {
            setTimeout(() => {
              el.classList.add('visible');
            }, index * 200);
          });
        }
      });
    };
    
    const observer = new IntersectionObserver(handleIntersection, { threshold: 0.1 });
    
    if (aboutRef.current) {
      observer.observe(aboutRef.current);
    }
    
    return () => {
      if (aboutRef.current) {
        observer.unobserve(aboutRef.current);
      }
    };
  }, []);
  
  return (
    <section id="about" ref={aboutRef} className="section bg-white">
      <div className="container-custom">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
          <div>
            <h2 className="section-heading animate-element slide-in-left">About Zubair Sites</h2>
            <p className="text-lg mb-6 animate-element slide-in-left">
              Zubair Sites is a 24/7 web development agency providing services including web development, software & application solutions, SEO and local SEO.
            </p>
            <p className="mb-6 animate-element slide-in-left">
              With over 9 years of experience and more than 200 websites completed, we have established ourselves as Kashmir's leading web development company. Our team of skilled developers, designers, and SEO experts work around the clock to deliver exceptional digital solutions for businesses of all sizes.
            </p>
            <p className="animate-element slide-in-left">
              Whether you need a simple business website or a complex e-commerce platform, we have the expertise to bring your vision to life with cutting-edge technology and creative design.
            </p>
          </div>
          
          <div className="relative h-80 animate-element slide-in-right">
            <div className="absolute top-0 right-0 w-full h-full bg-darkGreen rounded-lg transform rotate-3"></div>
            <div className="absolute top-0 right-0 w-full h-full bg-green rounded-lg -rotate-3"></div>
            <div className="absolute inset-0 flex items-center justify-center bg-white rounded-lg shadow-lg p-8">
              <div className="text-center">
                <h3 className="text-2xl font-bold text-darkGreen mb-4">Our Mission</h3>
                <p>To provide affordable, high-quality web solutions that help businesses thrive in the digital landscape.</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default About;