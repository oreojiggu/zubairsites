import React, { useEffect, useRef } from 'react';
import { Code, Layout, ShoppingBag, Globe, Search, Palette, Laptop, Wifi } from 'lucide-react';

interface Service {
  id: number;
  title: string;
  description: string;
  icon: React.ReactNode;
}

const Services: React.FC = () => {
  const servicesRef = useRef<HTMLDivElement>(null);
  
  const services: Service[] = [
    {
      id: 1,
      title: 'Custom Coded Websites',
      description: 'Tailored websites built from scratch with clean code and optimized performance.',
      icon: <Code className="h-8 w-8 text-green" />,
    },
    {
      id: 2,
      title: 'WordPress Websites',
      description: 'Custom WordPress development with responsive design and easy content management.',
      icon: <Layout className="h-8 w-8 text-green" />,
    },
    {
      id: 3,
      title: 'Shopify Websites',
      description: 'E-commerce solutions with Shopify to help you sell products online effectively.',
      icon: <ShoppingBag className="h-8 w-8 text-green" />,
    },
    {
      id: 4,
      title: 'Tour & Travel Website Development',
      description: 'Specialized websites for tour operators and travel agencies with booking features.',
      icon: <Globe className="h-8 w-8 text-green" />,
    },
    {
      id: 5,
      title: 'SEO & Local SEO',
      description: 'Comprehensive search engine optimization to improve your online visibility.',
      icon: <Search className="h-8 w-8 text-green" />,
    },
    {
      id: 6,
      title: 'Logo Design',
      description: 'Creative and unique logo designs that represent your brand identity.',
      icon: <Palette className="h-8 w-8 text-green" />,
    },
    {
      id: 7,
      title: 'Software & Application Development',
      description: 'Custom software solutions and mobile applications tailored to your business needs.',
      icon: <Laptop className="h-8 w-8 text-green" />,
    },
    {
      id: 8,
      title: 'NFC Cards',
      description: 'Google Review, TripAdvisor Review Cards, Social Media Cards with NFC technology.',
      icon: <Wifi className="h-8 w-8 text-green" />,
    },
  ];
  
  useEffect(() => {
    const handleIntersection = (entries: IntersectionObserverEntry[]) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          entry.target.classList.add('visible');
        }
      });
    };
    
    const observer = new IntersectionObserver(handleIntersection, { threshold: 0.1 });
    
    if (servicesRef.current) {
      observer.observe(servicesRef.current);
    }
    
    return () => {
      if (servicesRef.current) {
        observer.unobserve(servicesRef.current);
      }
    };
  }, []);
  
  return (
    <section id="services" ref={servicesRef} className="section bg-gray-50">
      <div className="container-custom">
        <h2 className="section-heading text-center mx-auto slide-up">Our Services</h2>
        <p className="text-center max-w-2xl mx-auto mb-12 slide-up">
          We offer a wide range of web development and digital marketing services to help your business grow online.
        </p>
        
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 stagger-animation">
          {services.map((service) => (
            <div
              key={service.id}
              className="card group hover:bg-darkGreen hover:text-white transition-all duration-300 slide-up"
            >
              <div className="mb-4 group-hover:text-white transition-colors duration-300">
                {service.icon}
              </div>
              <h3 className="text-xl font-semibold mb-2 group-hover:text-white transition-colors duration-300">
                {service.title}
              </h3>
              <p className="group-hover:text-white/80 transition-colors duration-300">
                {service.description}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Services;