import React, { useEffect, useRef, useState } from 'react';
import { ChevronDown, ChevronUp } from 'lucide-react';

interface FaqItem {
  id: number;
  question: string;
  answer: string;
}

const Faq: React.FC = () => {
  const faqRef = useRef<HTMLDivElement>(null);
  const [openItem, setOpenItem] = useState<number | null>(0);
  
  const faqs: FaqItem[] = [
    {
      id: 1,
      question: 'How long does a project take?',
      answer: 'Most projects take between 5 to 15 days to complete, depending on the complexity and specific requirements. We work efficiently to deliver high-quality websites within the agreed timeframe.',
    },
    {
      id: 2,
      question: 'Do you offer SEO with websites?',
      answer: 'Yes, we offer comprehensive SEO services with our websites. This includes on-page optimization, keyword research, meta tags, and ensuring your website follows best practices for search engine visibility.',
    },
    {
      id: 3,
      question: 'Can you create local SEO optimized business sites?',
      answer: 'Absolutely! We specialize in local SEO optimization for businesses targeting specific geographic areas. This includes Google My Business optimization, local keyword targeting, and strategies to improve your local search rankings.',
    },
    {
      id: 4,
      question: 'What technologies do you use?',
      answer: 'We use a variety of modern technologies including HTML5, CSS3, JavaScript, React, WordPress, Shopify, and other frameworks depending on project requirements. We always select the most appropriate technology stack for each specific project needs.',
    },
    {
      id: 5,
      question: 'Do you offer post-launch support?',
      answer: 'Yes, we provide comprehensive post-launch support to ensure your website continues to function smoothly. We offer maintenance packages to keep your site updated, secure, and performing optimally.',
    },
    {
      id: 6,
      question: 'Are revisions included?',
      answer: 'Yes, we include a reasonable number of revisions in our project quotes to ensure you\'re completely satisfied with the final product. We work closely with you throughout the development process to incorporate your feedback.',
    },
  ];
  
  const toggleItem = (id: number) => {
    setOpenItem(openItem === id ? null : id);
  };
  
  useEffect(() => {
    const handleIntersection = (entries: IntersectionObserverEntry[]) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          entry.target.classList.add('visible');
        }
      });
    };
    
    const observer = new IntersectionObserver(handleIntersection, { threshold: 0.1 });
    
    if (faqRef.current) {
      observer.observe(faqRef.current);
    }
    
    return () => {
      if (faqRef.current) {
        observer.unobserve(faqRef.current);
      }
    };
  }, []);
  
  return (
    <section id="faq" ref={faqRef} className="section bg-white">
      <div className="container-custom">
        <h2 className="section-heading text-center mx-auto slide-up">Frequently Asked Questions</h2>
        <p className="text-center max-w-2xl mx-auto mb-12 slide-up">
          Find answers to common questions about our services, process, and deliverables.
        </p>
        
        <div className="max-w-3xl mx-auto slide-up">
          {faqs.map((faq) => (
            <div key={faq.id} className="faq-item">
              <button
                className="faq-question"
                onClick={() => toggleItem(faq.id)}
                aria-expanded={openItem === faq.id}
              >
                <span>{faq.question}</span>
                {openItem === faq.id ? (
                  <ChevronUp className="h-5 w-5 text-green" />
                ) : (
                  <ChevronDown className="h-5 w-5 text-green" />
                )}
              </button>
              
              <div
                className={`faq-answer overflow-hidden transition-all duration-300 ${
                  openItem === faq.id ? 'max-h-96 opacity-100' : 'max-h-0 opacity-0'
                }`}
              >
                <p>{faq.answer}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Faq;