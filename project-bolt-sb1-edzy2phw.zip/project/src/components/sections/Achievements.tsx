import React, { useEffect, useRef, useState } from 'react';
import { Award, Clock } from 'lucide-react';

interface Achievement {
  id: number;
  value: number;
  label: string;
  suffix?: string;
  icon: React.ReactNode;
}

const Achievements: React.FC = () => {
  const achievementsRef = useRef<HTMLDivElement>(null);
  const [animatedValues, setAnimatedValues] = useState<number[]>([0, 0]);
  const [hasAnimated, setHasAnimated] = useState(false);
  
  const achievements: Achievement[] = [
    {
      id: 1,
      value: 200,
      label: 'Websites Completed',
      suffix: '+',
      icon: <Award className="h-10 w-10 text-green" />,
    },
    {
      id: 2,
      value: 9,
      label: 'Years of Experience',
      suffix: '+',
      icon: <Clock className="h-10 w-10 text-green" />,
    },
  ];
  
  useEffect(() => {
    const handleIntersection = (entries: IntersectionObserverEntry[]) => {
      entries.forEach(entry => {
        if (entry.isIntersecting && !hasAnimated) {
          entry.target.classList.add('visible');
          
          // Animate counter
          animateCounter();
          setHasAnimated(true);
        }
      });
    };
    
    const observer = new IntersectionObserver(handleIntersection, { threshold: 0.1 });
    
    if (achievementsRef.current) {
      observer.observe(achievementsRef.current);
    }
    
    return () => {
      if (achievementsRef.current) {
        observer.unobserve(achievementsRef.current);
      }
    };
  }, [hasAnimated]);
  
  const animateCounter = () => {
    const duration = 2000; // 2 seconds
    const frameDuration = 1000 / 60; // 60fps
    const totalFrames = Math.round(duration / frameDuration);
    
    let frame = 0;
    
    const counter = setInterval(() => {
      frame++;
      
      const progress = frame / totalFrames;
      const easedProgress = easeOutQuad(progress);
      
      const currentValues = achievements.map(achievement => 
        Math.floor(easedProgress * achievement.value)
      );
      
      setAnimatedValues(currentValues);
      
      if (frame === totalFrames) {
        clearInterval(counter);
        setAnimatedValues(achievements.map(achievement => achievement.value));
      }
    }, frameDuration);
  };
  
  // Easing function for smoother animation
  const easeOutQuad = (t: number): number => t * (2 - t);
  
  return (
    <section id="achievements" ref={achievementsRef} className="section bg-darkGreen text-white">
      <div className="container-custom">
        <h2 className="section-heading text-white text-center mx-auto slide-up">Our Achievements</h2>
        <p className="text-center max-w-2xl mx-auto mb-12 text-white/80 slide-up">
          We take pride in our work and the trust our clients place in us.
        </p>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-3xl mx-auto">
          {achievements.map((achievement, index) => (
            <div key={achievement.id} className="text-center bg-white/10 rounded-lg p-8 backdrop-blur-sm slide-up">
              <div className="inline-flex justify-center items-center mb-4 bg-white/10 p-4 rounded-full">
                {achievement.icon}
              </div>
              <h3 className="text-4xl md:text-5xl font-bold mb-2">
                {animatedValues[index]}{achievement.suffix || ''}
              </h3>
              <p className="text-lg text-white/80">{achievement.label}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Achievements;