import React, { useEffect, useRef } from 'react';

const Hero: React.FC = () => {
  const heroRef = useRef<HTMLDivElement>(null);
  
  useEffect(() => {
    const handleIntersection = (entries: IntersectionObserverEntry[]) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          entry.target.classList.add('visible');
        }
      });
    };
    
    const observer = new IntersectionObserver(handleIntersection, { threshold: 0.1 });
    
    if (heroRef.current) {
      observer.observe(heroRef.current);
    }
    
    return () => {
      if (heroRef.current) {
        observer.unobserve(heroRef.current);
      }
    };
  }, []);
  
  return (
    <section id="hero" ref={heroRef} className="relative min-h-screen flex items-center justify-center bg-darkGreen text-white overflow-hidden">
      <div className="absolute inset-0 z-0">
        {/* Animated background pattern */}
        <div className="absolute top-0 left-0 w-full h-full opacity-10">
          <div className="absolute top-0 left-0 w-32 h-32 rounded-full bg-green transform-gpu animate-pulse-slow"></div>
          <div className="absolute top-40 right-20 w-64 h-64 rounded-full bg-green transform-gpu animate-pulse-slow" style={{ animationDelay: '1s' }}></div>
          <div className="absolute bottom-20 left-40 w-48 h-48 rounded-full bg-green transform-gpu animate-pulse-slow" style={{ animationDelay: '2s' }}></div>
        </div>
      </div>
      
      <div className="container-custom relative z-10">
        <div className="text-center max-w-3xl mx-auto">
          <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold mb-6 slide-up">
            Best Web Development Agency in Kashmir
          </h1>
          
          <p className="text-lg md:text-xl mb-8 slide-up" style={{ animationDelay: '0.2s' }}>
            Premium web development services for businesses of all sizes. Grow your online presence with our custom solutions.
          </p>
          
          <div className="flex flex-col sm:flex-row justify-center gap-4 slide-up" style={{ animationDelay: '0.4s' }}>
            <a 
              href="tel:+91-9596320118" 
              className="btn btn-primary"
            >
              Call Us
            </a>
            <a 
              href="https://wa.me/919596320118" 
              className="btn btn-outline"
            >
              WhatsApp Us
            </a>
          </div>
        </div>
      </div>
      
      <div className="absolute bottom-10 left-1/2 transform -translate-x-1/2 animate-bounce">
        <a href="#about" aria-label="Scroll down">
          <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 14l-7 7m0 0l-7-7m7 7V3" />
          </svg>
        </a>
      </div>
    </section>
  );
};

export default Hero;